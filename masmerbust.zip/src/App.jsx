export default function MasmerbustApp(){
  return <div className="p-10 text-center text-xl">Проект masmerbust готов. Вставьте сюда код приложения из документа.</div>
}